package com.example.cs360_project2;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class WeightDataActivity extends AppCompatActivity {

    //SMS permission
    private static final int SMS_PERMISSION_CODE = 100;

    private DBHelper dbHelper; //database helper
    private TableLayout tableLayout; //layout for weight values
    private Button enterWeightButton, notifyButton; //buttons for adding weight and notifying

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_data);

        // Initializes DBHelper
        dbHelper = new DBHelper(this);

        // Links to layout xml
        tableLayout = findViewById(R.id.tableLayout);
        enterWeightButton = findViewById(R.id.button); // button that allows weight entering
        notifyButton = findViewById(R.id.button3);      // button for notifications

        // Load weights already logged
        loadWeights();

        // asks user for SMS permission
        checkSmsPermission();

        // brings up dialog box when "Enter Weight is clicked
        enterWeightButton.setOnClickListener(v -> showAddWeightDialog());

        // when clicked send SMS if approved
        notifyButton.setOnClickListener(v -> sendTestSms());
    }

    // Load all saved entries into table
    private void loadWeights() {
        //clears rows except header
        int childCount = tableLayout.getChildCount();
        while (childCount > 1) {
            tableLayout.removeViewAt(1);
            childCount--;
        }
        //gets data and builds rows
        var cursor = dbHelper.getAllWeights();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow(DBHelper.WEIGHT_ID));
            String date = cursor.getString(cursor.getColumnIndexOrThrow(DBHelper.WEIGHT_DATE));
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(DBHelper.WEIGHT_VALUE));

            TableRow row = new TableRow(this);
            //date
            TextView tvDate = new TextView(this);
            tvDate.setText(date + ": ");
            tvDate.setTextAppearance(this, android.R.style.TextAppearance_Medium);

            //weight
            TextView tvWeight = new TextView(this);
            tvWeight.setText(String.format(Locale.US, "%.1f lbs.", weight));

            //delete button
            Button btnDelete = new Button(this);
            btnDelete.setText("Delete");
            btnDelete.setOnClickListener(v -> {
                //delete from database and refreshes the table
                dbHelper.deleteWeight(id);
                loadWeights();
                Toast.makeText(this, "Entry deleted", Toast.LENGTH_SHORT).show();
            });

            //add views to row and then adds row to table
            row.addView(tvDate);
            row.addView(tvWeight);
            row.addView(btnDelete);
            tableLayout.addView(row);
        }
        cursor.close();
    }

    // Add new weight
    private void showAddWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Your New Weight");

        //input for new weight
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setHint("Enter Current weight");
        builder.setView(input);

        //when user presses "Enter", adds to database
        builder.setPositiveButton("Enter", (dialog, which) -> {
            String weightStr = input.getText().toString();
            if (!weightStr.isEmpty()) {
                String currentDate = new SimpleDateFormat("MM/dd/yyyy", Locale.US)
                        .format(System.currentTimeMillis());
                double weight = Double.parseDouble(weightStr);

                if (dbHelper.addWeight(currentDate, weight)) {
                    Toast.makeText(this, "Weight updated", Toast.LENGTH_SHORT).show();
                    loadWeights();

                    // Notify if goal weight is reached, future would love to
                    // develop a feature where on creation you can enter a goal weight
                    if (weight <= 150) sendSms("Goal weight! WOOO!");
                } else {
                    Toast.makeText(this, "Failed to add weight", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // User clicking cancel
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    // Asks for SMS permission
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // Handle permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Great we'll send you messages", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Messages disabled.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Send test SMS via Notify button
    private void sendTestSms() {
        sendSms("Test Message: Your weight data has been updated.");
    }

    // Generic method for sending a message
    private void sendSms(String message) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = SmsManager.getDefault();
                String phoneNumber = "1234567890"; // placeholder, replace with real number in real app
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(this, "Message sent!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "message failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Cannot send notification, permission denied", Toast.LENGTH_SHORT).show();
        }
    }
}