package com.example.cs360_project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "weighttracker.db";

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String USER_ID = "id";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String GOAL_WEIGHT = "goal_weight";

    // Weights table
    public static final String TABLE_WEIGHTS = "weights";
    public static final String WEIGHT_ID = "id";
    public static final String WEIGHT_DATE = "date";
    public static final String WEIGHT_VALUE = "weight";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users table
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USERNAME + " TEXT UNIQUE, " +
                PASSWORD + " TEXT, " +
                GOAL_WEIGHT + " REAL)");

        // Create Weights table
        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " (" +
                WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                WEIGHT_DATE + " TEXT, " +
                WEIGHT_VALUE + " REAL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        onCreate(db);
    }

    // Add a new user
    public boolean addUser(String username, String password, double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USERNAME, username);
        values.put(PASSWORD, password);
        values.put(GOAL_WEIGHT, goalWeight);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Check if user exists and password matches
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{USER_ID},
                USERNAME + "=? AND " + PASSWORD + "=?",
                new String[]{username, password}, null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Add a new weight
    public boolean addWeight(String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WEIGHT_DATE, date);
        values.put(WEIGHT_VALUE, weight);

        long result = db.insert(TABLE_WEIGHTS, null, values);
        return result != -1;
    }

    // Get all weights
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.query(TABLE_WEIGHTS, null, null, null, null, null, WEIGHT_DATE + " DESC");
    }

    // Delete a weight entry by ID
    public boolean deleteWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_WEIGHTS, WEIGHT_ID + "=?", new String[]{String.valueOf(id)});
        return result > 0;
    }
}