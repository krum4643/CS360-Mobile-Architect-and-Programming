package com.example.cs360_project2;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    //username and password inputs
    private EditText yourUsername, yourPassword;

    //login and create new user logins
    private Button loginButton, createNewUserButton;

    //SQLLite
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // initializes my ui elements
        yourUsername = findViewById(R.id.editTextUsername);
        yourPassword = findViewById(R.id.editTextPassword);
        loginButton = findViewById(R.id.buttonLogin);
        createNewUserButton = findViewById(R.id.buttonCreateUser);

        // initializes DB helper creates the database
        dbHelper = new DBHelper(this);

        // login button is pressed
        loginButton.setOnClickListener(v -> {
            // read the input the user provides
            String username = yourUsername.getText().toString().trim();
            String password = yourPassword.getText().toString().trim();

            // if there is an empty field show this message and exit
            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Enter your username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // check if the username and password is located in the database
            if (dbHelper.checkUser(username, password)) {
                //if the credentials are valid go to weightDataActivty
                Toast.makeText(this, "Successfully logged in!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(this, WeightDataActivity.class);
                //pass the username into the next activity
                intent.putExtra("username", username);
                startActivity(intent);
                //closes login screen so user can't return
                finish();
            } else {
                //invalid credentials entered
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            }
        });

        // if the user creates a new login, try to add user to database
        createNewUserButton.setOnClickListener(v -> {
            String username = yourUsername.getText().toString().trim();
            String password = yourPassword.getText().toString().trim();
            double defaultGoalWeight = 150.0; //example default goal weight for user

            // make sure the user has entered values
            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                return;
            }

            // try to insert new user in database
            if (dbHelper.addUser(username, password, defaultGoalWeight)) {
                Toast.makeText(this, "User created! Proceed to login.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Creation has failed, try again", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
